package com.practice.practicespringbootjpa.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "User")
public class User {
    @Id //设置ID字段
    @GeneratedValue(strategy = GenerationType.AUTO)//自增长字段
    private Long id;
    private String name;
    private String gender;

}
