package com.practice.practicespringbootjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//启动类：启动类应放于包的根下，启动类在启动时会扫描所有注解，Spring Boot所有配置都是基于注解的
@SpringBootApplication
public class PracticespringbootjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticespringbootjpaApplication.class, args);
	}

}
