package com.practice.practicespringbootjpa.controller;

import com.practice.practicespringbootjpa.model.User;
import com.practice.practicespringbootjpa.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class JpaPracticeController {
    @Autowired //完成自动导入
    private UserService userService;
//    @Autowired
//    UserRepository userRepository;
    @GetMapping("/findallusers")
    public List<User> getAllUsers(){
        return userService.getAllUsers();
//        return userRepository.findAll();
    }
}
